import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Vector;

public class Zamowienie {
    private List<Faktura> faktury = new ArrayList<>();
    private long numerZamowienia;
    private Date dataZamowienia;
    private Date dataRealizacji;
    private long numerFaktury;

    private ArrayList<KlientZamowienie> klientZamowienie = new ArrayList<KlientZamowienie>();

    public Zamowienie(long numerZamowienia, Date dataRealizacji, Date dataZamowienia){
        if(cheakForNull(numerZamowienia))
            this.numerZamowienia = numerZamowienia;
        if(cheakForNull(dataRealizacji))
            this.dataRealizacji = dataRealizacji;
        if(cheakForNull(dataZamowienia))
            this.dataZamowienia = dataZamowienia;
    }

    public Faktura utworzFakture(long numerFaktury, Date dataWystawienia){
        this.numerFaktury = numerFaktury;
        Faktura faktura = new Faktura(numerFaktury, dataWystawienia);
        faktury.add(faktura);

        return faktura;
    }

    public boolean cheakForNull(Object ob) throws NullPointerException{
        if(ob == null)
            throw new NullPointerException("Null");
        return true;
    }

    public void addKlientZam(KlientZamowienie klientZamowienie) {
        if (!this.klientZamowienie.contains(klientZamowienie))
            this.klientZamowienie.add(klientZamowienie);
    }

    public Date getDataZamowienia(){
        return dataZamowienia;
    }

    public Date getDataRealizacji(){
        return dataRealizacji;
    }

    public long getNumerZamowienia(){
        return numerZamowienia;
    }

    public String toString(){
        String st = new String();

        st += "Zamowienie №" + numerZamowienia + " — \n"
                + "Data zamowienia: " + dataZamowienia + "\n"
                + "Data realizacji: " + dataRealizacji + "\n"
                + "Numer faktury: " + numerFaktury + "\n";

        for(KlientZamowienie dp : klientZamowienie) {
            st += "Adres dostawy: " + dp.getAdresDostawy() + "\n" + "Cena zamowienia: " + dp.getCeneZamowienia() + "\n";
        }


        return st;
    }

    public class Faktura{
        private long numerFaktury;
        private Date dataWystawienia;

        public Faktura(long numerFaktury, Date dataWystawienia){
            if(cheakForNull(numerFaktury))
                this.numerFaktury = numerFaktury;
            if(cheakForNull(dataWystawienia))
                this.dataWystawienia = dataWystawienia;
        }

        public boolean cheakForNull(Object ob) throws NullPointerException{
            if(ob == null)
                throw new NullPointerException("Null");
            return true;
        }

        public long getNumerFaktury(){
            return numerFaktury;
        }

        public Date getDataWystawienia(){
            return dataWystawienia;
        }
    }
}
