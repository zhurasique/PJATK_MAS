import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Main {
    public static void main(String[]args) throws Exception {
        // Kompozycja
        DateFormat dateFormat = new SimpleDateFormat("mm/dd/yyyy");
        Date dataZamowienia = dateFormat.parse("03/08/2001");
        Date dataRelizacji = dateFormat.parse("03/04/2001");
        Zamowienie zm = new Zamowienie(1, dataRelizacji, dataZamowienia);
        zm.utworzFakture(1, dataRelizacji);
        System.out.println(zm);

        // Zwykla
        Miasto miasto = new Miasto("Warszawa", "Mazowieckie");
        Klient km = new Klient(2, "Wasdxa 21", "21312", "234124@pl.pl", miasto);
        miasto.showAllKlients();

        // Z atrybutem
        Klient k1 = new Klient(1, "Obozowa 21", "2222", "osp@pl.pl", miasto);
        KlientZamowienie kz = new KlientZamowienie(k1, zm, "Koszykowa 86", 240.40);
        k1.addKlientZam(kz);
        zm.addKlientZam(kz);
        System.out.println(zm);

        // Kwalifikowana
        Klient k2 = new Klient(2, "Kaczorowska 8", "888", "kacz@pl.ua", miasto);
        Zamowienie z2 = new Zamowienie(2, dataRelizacji, dataZamowienia);
        KlientZamowienie kz2 = new KlientZamowienie(k2, z2, "Magistracka 22", 7777.22);
        z2.utworzFakture(2, dataRelizacji);
        k2.makeOrder(z2);
        k1.addKlientZam(kz2);
        z2.addKlientZam(kz2);
        System.out.println(z2);

        System.out.println(k2.findOrder(0));
    }
}
