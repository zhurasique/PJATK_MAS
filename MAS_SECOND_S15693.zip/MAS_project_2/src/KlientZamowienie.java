public class KlientZamowienie {
    Klient klient;
    Zamowienie zamowienie;

    private String adresDostawy;
    private double ceneZamowienia;

    public KlientZamowienie(Klient klient, Zamowienie zamowienie, String adresDostawy, double ceneZamowienia){
        if(cheakForNull(klient))
            this.klient = klient;
        if(cheakForNull(zamowienie))
            this.zamowienie = zamowienie;
        if(cheakForNull(adresDostawy))
            this.adresDostawy = adresDostawy;
        if(cheakForNull(ceneZamowienia))
            this.ceneZamowienia = ceneZamowienia;
    }

    public boolean cheakForNull(Object ob) throws NullPointerException{
        if(ob == null)
            throw new NullPointerException("Null");
        return true;
    }

    public String getAdresDostawy(){
        return adresDostawy;
    }

    public double getCeneZamowienia(){
        return ceneZamowienia;
    }
}
