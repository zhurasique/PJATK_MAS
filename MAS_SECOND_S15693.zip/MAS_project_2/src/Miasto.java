import java.util.ArrayList;
import java.util.List;

public class Miasto {
    private String nazwa;
    private String wojewodstwo;

    private List<Klient> klients = new ArrayList<>();

    public Miasto(String nazwa, String wojewodstwo){
        if(cheakForNull(nazwa))
            this.nazwa = nazwa;
        if(cheakForNull(wojewodstwo))
            this.wojewodstwo = wojewodstwo;
    }

    public boolean cheakForNull(Object ob) throws NullPointerException{
        if(ob == null)
            throw new NullPointerException("Null");
        return true;
    }

    public void addKlient(Klient klient){
        klients.add(klient);
    }

    public void showAllKlients(){
        for(Klient kp : klients)
            System.out.println("Klient: " + kp);
    }
}
