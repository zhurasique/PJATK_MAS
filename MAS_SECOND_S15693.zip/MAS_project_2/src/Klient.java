import java.util.*;

public class Klient {
    private long numer;
    private String adres;
    private String telefon;
    private String email;
    private static int count = 0;
    private ArrayList<KlientZamowienie> klientZamowienie = new ArrayList<KlientZamowienie>();
    private HashMap<Integer, Zamowienie> wszystkieZamowienia = new HashMap<>();
    private Miasto miasto;

    public Klient(long numer, String adres, String telefon, String email, Miasto miasto){
        if(cheakForNull(numer))
            this.numer = numer;
        if(cheakForNull(adres))
            this.adres = adres;
        if(cheakForNull(telefon))
            this.telefon = telefon;
        if(cheakForNull(email))
            this.email = email;
        if(cheakForNull(miasto)) {
            this.miasto = miasto;
            miasto.addKlient(this);
        }
    }

    public boolean cheakForNull(Object ob) throws NullPointerException{
        if(ob == null)
            throw new NullPointerException("Null");
        return true;
    }

    public void addKlientZam(KlientZamowienie klientZamowienie) {
        if (!this.klientZamowienie.contains(klientZamowienie))
            this.klientZamowienie.add(klientZamowienie);
    }

    public void makeOrder(Zamowienie zamowienie) throws NullPointerException{
        if(!wszystkieZamowienia.containsKey(count)) {
            wszystkieZamowienia.put(count, zamowienie);
            count++;
        }else
            throw new NullPointerException("Null");
    }

    public Zamowienie findOrder(int id) throws Exception {
        if(!wszystkieZamowienia.containsKey(id)) {
            throw new Exception("Nie odnaleziono zamowienia o id: " + id);
        }
        return wszystkieZamowienia.get(id);
    }

    public String toString(){
        return "Numer klienta: " + numer + "\n"
                + "Adreas klienta: " + adres + "\n"
                + "Telefon klienta: " + numer + "\n"
                + "Email klienta: " + numer + "\n";
    }
}
