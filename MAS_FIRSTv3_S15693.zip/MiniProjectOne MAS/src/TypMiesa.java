public enum TypMiesa {
    Wieprzowina, Wolowina, Kurczak, Baranina, Cielecina;
}
