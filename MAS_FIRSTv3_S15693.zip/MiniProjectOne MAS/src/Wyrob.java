
import javax.xml.crypto.Data;
import java.text.DateFormat;
import java.util.Date;
import java.util.List;

public
    class Wyrob extends ObjectPlus{

    private static final long serialVersionUID = 1L;

    private String nazwa;
    private Double waga;
    private String gatunek; //atrybut opcjonalny
    private List<String> skladniki; //atrybut powtarzalny
    private Long numer;
    private static double calkowitaWaga = 0; //atrybut klasowy
    private final double minimalnaWaga = 4.44; //atrybut pochodny
    private Mieso mieso;
    private int numerS = 0;
    private String osobaS;
    private Date dataProdukcji; //atrybut zlozony

    public Wyrob(String nazwa, Double waga, String gatunek, List<String> skladniki, Long numer, Mieso mieso, Date dataProdukcji){
        super();
        ustawDateProdukcji(dataProdukcji);
        ustawNazwe(nazwa);
        ustawNumer(numer);
        ustawSkladniki(skladniki);
        ustawWage(waga);

        this.gatunek = gatunek;

        calkowitaWaga += waga;
    }

    public void ustawNazwe(String nrTelefonu){
        if(nrTelefonu == null){throw new NullPointerException("Pole nrTelefonu nie może być puste.");}//Atrybut wymagany
        this.nazwa = nazwa;
    }

    public void ustawWage(Double waga){
        if(waga == null){throw new NullPointerException("Pole nrTelefonu nie może być puste.");}//Atrybut wymagany
        if(waga < setMinWaga(minimalnaWaga)){throw new NullPointerException("Waga musi byc wieksza");}
        this.waga = waga;
    }

    public void ustawSkladniki(List<String> skladniki){
        if(skladniki == null){throw new NullPointerException("Pole nrTelefonu nie może być puste.");}//Atrybut wymagany
        this.skladniki = skladniki;
    }

    public void ustawNumer(Long numer){
        if(numer == null){throw new NullPointerException("Pole nrTelefonu nie może być puste.");}//Atrybut wymagany
        this.numer = numer;
    }

    public void ustawDateProdukcji(Date dataProdukcji){
        if(dataProdukcji == null){throw new NullPointerException("Pole nrTelefonu nie może być puste.");}//Atrybut wymagany
        this.dataProdukcji = dataProdukcji;
    }

    //metoda pochodna
    public final double setMinWaga(double minimalnaWaga){
        return minimalnaWaga;
    }


    //metoda klasowa
    public static double getCalkowitaWaga() {
        return calkowitaWaga;
    }

    //przeciozenie metod
    public String dodajSprawdzenie(String nazwiskoOsoby) throws Exception {
        if(nazwiskoOsoby == null)
            throw new Exception("Sprawdzenie musi miec osobe.");
        osobaS = nazwiskoOsoby;
        return nazwiskoOsoby;
    }

    public int dodajSprawdzenie(int numerSprawdzenia) throws Exception {
        numerS = numerSprawdzenia;
        return numerSprawdzenia;
    }

    //przesloniecie metody toString()
    @Override
    public String toString(){
        String join = "";
        join += "Nazwa: " + nazwa + "\n" +
                "Waga: " + waga + "\n" +
                "Skladniki: " + skladniki + "\n" +
                "Numer: " + numer + "\n" +
                "Numer sprawdzenia: " + numerS + " przez osobe - " + osobaS +
                "\n\t Calkowita waga: " + getCalkowitaWaga();
                if(gatunek != null)
                   join += "Gatunek: " + gatunek;
        return join;
    }

    public void setNazwa(String nazwa) {
        this.nazwa = nazwa;
    }

    public void setWaga(Double waga) {
        this.waga = waga;
    }

    public void setGatunek(String gatunek) {
        this.gatunek = gatunek;
    }

    public void setSkladniki(List<String> skladniki) {
        this.skladniki = skladniki;
    }

    public void setNumer(Long numer) {
        this.numer = numer;
    }

    public static void setCalkowitaWaga(double calkowitaWaga) {
        Wyrob.calkowitaWaga = calkowitaWaga;
    }

    public void setMieso(Mieso mieso) {
        this.mieso = mieso;
    }

    public String getNazwa() {
        return nazwa;
    }

    public Double getWaga() {
        return waga;
    }

    public String getGatunek() {
        return gatunek;
    }

    public List<String> getSkladniki() {
        return skladniki;
    }

    public Long getNumer() {
        return numer;
    }

    public Mieso getMieso() {
        return mieso;
    }
}
