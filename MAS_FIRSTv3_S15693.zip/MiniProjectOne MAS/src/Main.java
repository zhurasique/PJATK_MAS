import javafx.scene.input.DataFormat;

import javax.xml.crypto.Data;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Main {
	public static void main(String[] args) throws Exception {
		if(new File("Miasaa").isFile()) {
			try {
				FileInputStream fileInput = new FileInputStream("Miasaa");
				ObjectInputStream streamInput = new ObjectInputStream(fileInput);
				ObjectPlus.odczytajEkstensje(streamInput);
				streamInput.close();
				fileInput.close();
			} catch(IOException i){
				i.printStackTrace();
				return;
			} catch(ClassNotFoundException c){
				System.out.println("Nie znaleziono klasy.");
				c.printStackTrace();
				return;
			}
		}
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
		Date date = dateFormat.parse("2000/08/03");

		Mieso mieso = new Mieso((long) 2222, TypMiesa.Kurczak);
		List<String> skladniki = new ArrayList<>();
		skladniki.add("sol");
		skladniki.add("pieprz");
		Wyrob wyrob = new Wyrob("Kielbasa", 44.7, null, skladniki, (long) 2222, mieso, date);
		wyrob.dodajSprawdzenie(222);
		wyrob.dodajSprawdzenie("Kowalski Piotr");
		ObjectPlus.pokazEkstensje(Wyrob.class);

		Mieso miesoS= new Mieso((long) 2223, TypMiesa.Baranina);
		List<String> skladnikiS = new ArrayList<>();
		skladnikiS.add("aloe");
		Wyrob wyrobS = new Wyrob("Kabanos", 22.2, "Pierwszy", skladnikiS, (long) 3333, miesoS, date);
		wyrobS.dodajSprawdzenie(333);
		wyrobS.dodajSprawdzenie("Kowalski Michal");
		ObjectPlus.pokazEkstensje(Wyrob.class);

		try {
			FileOutputStream fileOutput = new FileOutputStream("Miasaa");
			ObjectOutputStream StreamOutput = new ObjectOutputStream(fileOutput);
			ObjectPlus.zapiszEkstensje(StreamOutput);
			StreamOutput.close();
			fileOutput.close();
		} catch(IOException i) {
			i.printStackTrace();
		}
	}
}
