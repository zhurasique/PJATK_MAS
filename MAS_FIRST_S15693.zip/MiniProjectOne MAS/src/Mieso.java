import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public
    class Mieso implements Serializable  {
    private Long numer;
    private TypMiesa typMiesa;
    private static final long serialVersionUID = 1L;

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public void setNumer(Long numer) {
        this.numer = numer;
    }

    public void setTypMiesa(TypMiesa typMiesa) {
        this.typMiesa = typMiesa;
    }

    public Long getNumer() {
        return numer;
    }

    public TypMiesa getTypMiesa() {
        return typMiesa;
    }

    public Mieso(Long numer, TypMiesa typMiesa){
        if(numer == null){throw new NullPointerException("Pole numer nie może być puste.");}
            this.numer = numer;
        if(typMiesa == null){throw new NullPointerException("Pole typMiesa nie może być puste.");}
            this.typMiesa = typMiesa;
    }
}
