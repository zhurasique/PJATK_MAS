import javafx.scene.input.DataFormat;

import javax.xml.crypto.Data;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Main {

	public static void main(String[] args) throws Exception {
		
		//wczytuje to co było ostatnio zapisane
		if(new File("Miasaa").isFile())
		{
			try
			{
				//miejsce docelowe pliku w workspace
				FileInputStream fileInput = new FileInputStream("Miasaa");
				ObjectInputStream streamInput = new ObjectInputStream(fileInput);
				//odczyt z dysku do pliku "daneFirmowe"
				ObjectPlus.odczytajEkstensje(streamInput);
				streamInput.close();
				fileInput.close();
			}
			catch(IOException i){
				i.printStackTrace();
				return;
			}
			catch(ClassNotFoundException c){
				System.out.println("Nie znaleziono klasy.");
				c.printStackTrace();
				return;
			}
		}


		//utworzenie Pilota
		Mieso mieso = new Mieso((long) 2222, TypMiesa.Kurczak);
		List<String> skladniki = new ArrayList<>();
		skladniki.add("sol");
		skladniki.add("pieprz");
		Wyrob wyrob = new Wyrob("Kielbasa-bielbasa", 22.2, null, skladniki, (long) 2222, mieso);
		wyrob.dodajSprawdzenie(222);
		wyrob.dodajSprawdzenie("Kowalski");
		ObjectPlus.pokazEkstensje(Wyrob.class);

		Mieso miesoS= new Mieso((long) 2223, TypMiesa.Kurczak);
		List<String> skladnikiS = new ArrayList<>();
		skladnikiS.add("aloe");
		Wyrob wyrobS = new Wyrob("Kielbasa-bielbasa", 22.2, "Super", skladnikiS, (long) 2222, miesoS);
		wyrobS.dodajSprawdzenie(333);
		wyrobS.dodajSprawdzenie("Exxx");
		ObjectPlus.pokazEkstensje(Wyrob.class);



		try
		{
			//miejsce docelowe pliku w workspace
			//zapis z dysku do pliku "daneFirmowe"
			FileOutputStream fileOutput = new FileOutputStream("Miasaa");
			ObjectOutputStream StreamOutput = new ObjectOutputStream(fileOutput);
			ObjectPlus.zapiszEkstensje(StreamOutput);
			StreamOutput.close();
			fileOutput.close();
		}
		catch(IOException i)
		{
			i.printStackTrace();
		}

	}

}
