
import java.util.List;

public
    class Wyrob extends ObjectPlus{

    private static final long serialVersionUID = 1L;

    private String nazwa;
    private Double waga;
    private String gatunek; //atrybut opcjonalny
    private List<String> skladniki;//atrybut powtarzalny
    private Long numer;
    private static double calkowitaWaga = 0;//atrybut klasowy, atrybut pochodny
    private Mieso mieso;// atrybut zlozony
    private int numerS = 0;
    private String osobaS;

    public Wyrob(String nazwa, Double waga, String gatunek, List<String> skladniki, Long numer, Mieso mieso){
        super();
        if(nazwa == null){throw new NullPointerException("Pole nazwa nie może być puste.");}
        this.nazwa = nazwa;
        if(waga == null){throw new NullPointerException("Pole waga nie może być puste.");}
        this.waga = waga;
        if(skladniki == null){throw new NullPointerException("Pole skladniki nie może być puste.");}
        this.skladniki = skladniki;
        if(numer == null){throw new NullPointerException("Pole numer nie może być puste.");}
        this.numer = new Long(numer);
        this.mieso = mieso;
        this.gatunek = gatunek;
        calkowitaWaga += waga;
    }

    public void setNazwa(String nazwa) {
        this.nazwa = nazwa;
    }

    public void setWaga(Double waga) {
        this.waga = waga;
    }

    public void setGatunek(String gatunek) {
        this.gatunek = gatunek;
    }

    public void setSkladniki(List<String> skladniki) {
        this.skladniki = skladniki;
    }

    public void setNumer(Long numer) {
        this.numer = numer;
    }

    public static void setCalkowitaWaga(double calkowitaWaga) {
        Wyrob.calkowitaWaga = calkowitaWaga;
    }

    public void setMieso(Mieso mieso) {
        this.mieso = mieso;
    }

    public String getNazwa() {
        return nazwa;
    }

    public Double getWaga() {
        return waga;
    }

    public String getGatunek() {
        return gatunek;
    }

    public List<String> getSkladniki() {
        return skladniki;
    }

    public Long getNumer() {
        return numer;
    }
    //metoda klasowa
    public static double getCalkowitaWaga() {
        return calkowitaWaga;
    }

    public Mieso getMieso() {
        return mieso;
    }

    public String dodajSprawdzenie(String nazwiskoOsoby) throws Exception {
        if(nazwiskoOsoby == null)
            throw new Exception("Sprawdzenie musi miec osobe.");
        osobaS = nazwiskoOsoby;
        return nazwiskoOsoby;
    }

    public int dodajSprawdzenie(int numerSprawdzenia) throws Exception {
        numerS = numerSprawdzenia;
        return numerSprawdzenia;
    }

    //przesloniecie metody toString()
    @Override
    public String toString(){
        String join = "";
        join += "Nazwa: " + nazwa + "\n" +
                "Waga: " + waga + "\n" +
                "Skladniki" + skladniki + "\n" +
                "Numer: " + numer + "\n" +
                "Gatunek: " + gatunek + "\n" +
                "Numer sprawdzenia: " + numerS + " przez osobe - " + osobaS +
                "\n\t Calkowita waga: " + calkowitaWaga;

        return join;
    }
}
