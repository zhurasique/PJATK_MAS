import java.util.Date;

public abstract class Osoba extends ObjectPlus {

	private static final long serialVersionUID = 1L;//wymagane do serializacji,
	
	protected String imie;// atrybut prosty, wymagany, pojedynczy, obiektu
	protected String nazwisko;// atrybut prosty, wymagany, pojedynczy, obiektu
	protected Date dataUrodzenia;// atrybut zlozony, opcjonalny, pojedynczy, obiektu
	protected String adres;// atrybut prosty, opcjonalny, pojedynczy, obiektu
	protected String nrTelefonu;// atrybut prosty, wymagany, pojedynczy, obiektu
	protected String plec;// atrybut prosty, wymagany, pojedynczy, obiektu
	protected int iloscDzieci;// atrybut potrzebny do wyliczen
	protected static double sredniaIloscDzieci;// atrybut prosty, pojedynczy, wyliczalny (pochodny), klasowy
	private static int iloscOsob = 0; // atrybut prosty, pojedynczy, klasowy - potrzebny do liczenia sredniej

	//konstruktor Osoby
	Osoba(String imieOsoby, String nazwiskoOsoby, Date dataUrodzeniaOsoby, String adresOsoby, String nrTelefonuOsoby,String plecOsoby, int iloscDzieciOsoby)
	{
	
		super();//uruchomienie konstruktora w klasie ObjectPlus(tworzenie listy ekstensji)	
		
		if(imieOsoby == null){throw new NullPointerException("Pole imie nie może być puste.");}//sprawdzenie czy atrybut nie jest pusty
		this.imie = imieOsoby;
		
		if(nazwiskoOsoby == null){throw new NullPointerException("Pole nazwisko nie może być puste.");}//sprawdzenie czy atrybut nie jest pusty
		this.nazwisko = nazwiskoOsoby;
		
		if(nrTelefonuOsoby == null){throw new NullPointerException("Pole nr Telefonu nie może być puste.");}//sprawdzenie czy atrybut nie jest pusty
		this.nrTelefonu = nrTelefonuOsoby;
		
		if(plecOsoby == null){throw new NullPointerException("Pole płeć nie może być puste.");}//sprawdzenie czy atrybut nie jest pusty
		this.plec = plecOsoby;
		
		this.dataUrodzenia = dataUrodzeniaOsoby;
		
		this.iloscDzieci = iloscDzieciOsoby;
		
		this.adres = adresOsoby;
		
		iloscOsob++;
		sredniaIloscDzieci += (this.iloscDzieci - sredniaIloscDzieci) / iloscOsob; //wyliczzanie średniej ilości dziecka na osobe
		
	}
	
	
	//PRZESLANIANIE METOD (Pilot vs Osoba)
	public String getImie(){
		return this.imie;
	}
	
	public String getNazwisko(){
		return this.nazwisko;
	}
	
	public String getNrTelefonu(){
		return this.nrTelefonu;
	}
	
	public String getPlec(){
		return this.plec;
	}
	
	public String getAdres(){
		return this.adres;
	}
	
	public Date getDataUrodzenia(){
		return this.dataUrodzenia;
	}
	
	public int getIloscDzieci(){
		return this.iloscDzieci;
	}
	//meteda klasowa operuje na zmiennych klasowych
	public static double getSredniaIloscDzieci(){
		return sredniaIloscDzieci;
	}
	//atrybut wymagany
	public void ustawImie(String imie){
		if(imie == null){throw new NullPointerException("Pole imie nie może być puste.");}//Atrybut wymagany
		this.imie = imie;
	}
	
	public void ustawNazwisko(String nazwisko){
		if(nazwisko == null){throw new NullPointerException("Pole nazwisko nie może być puste.");}//Atrybut wymagany
		this.nazwisko = nazwisko;
	}
	
	public void ustawDateUrodzenia(Date dataUrodzenia){
		this.dataUrodzenia = dataUrodzenia; //Atrybut opcjionalny
	}
	
	public void ustawNrTelefonu(String nrTelefonu){
		if(nrTelefonu == null){throw new NullPointerException("Pole nrTelefonu nie może być puste.");}//Atrybut wymagany
		this.nrTelefonu = nrTelefonu;
	}
	
	public void ustawPlec(String plec){
		if(plec == null){throw new NullPointerException("Pole plec nie może być puste.");}//Atrybut wymagany
		this.plec = plec;
	}
	//atrybut opcjionalny
	public void ustawAdres(String adres)
	{
		this.adres = adres;
	}
	
	public void ustawIloscDzieci(int iloscDzieci){
		
		this.iloscDzieci = iloscDzieci;
	}
	
	public String toString(){
		String join = new String();
		join += "Osoba:\nImie: " +getImie() + 
				"\nNazwisko: " + getNazwisko() + 
				"\nNr Telefonu: ";
			join += nrTelefonu;
			
		join += "\nData Urodzenia: ";
		if(dataUrodzenia != null)//opcjionalny
			join += dataUrodzenia;
		else
			join += "brak danych";
		
		join += "\nAdres: ";
		if(adres != null)//opcjionalny
			join += adres;
		else
			join += "brak danych";
		
		join += "\nPłeć: " + getPlec();
		
		join += "\nLiczba dzieci: ";	
		if(iloscDzieci == 0)
			join += "brak";
		else
			join += getIloscDzieci();
			
		return join;
	}
	
}

