import java.util.Date;
import java.util.Vector;

public class Pilot extends Osoba {

	private static final long serialVersionUID = 1L;//wymagane do serializacji
	
	private Vector<String> typLicencji = new Vector<String>();// atrybut prosty, powtarzalny, obiektu
	private boolean wynikiBadan;
	private Vector<String> znajomoscMaszyn = new Vector<String>();// atrybut prosty, powtarzalny, obiektu
	private int minimalnaDlugoscKursow; //liczona w dniach
	
	
	
	Pilot (String imieOsoby, String nazwiskoOsoby, Date dataUrodzeniaOsoby, String adresOsoby, String nrTelefonuOsoby,String plecOsoby, int iloscDzieciOsoby)
	{
		//dziedziczenie poprzez super z klasy OSOBA
		super(imieOsoby,nazwiskoOsoby,dataUrodzeniaOsoby,adresOsoby, nrTelefonuOsoby, plecOsoby, iloscDzieciOsoby);
	}
	//PRZESLANIANIE METOD
	public String getImie()
	{
		return "Pilot " + this.imie;
	}
	
	public int minimalnaDlugoscKursow()
	{
		return this.minimalnaDlugoscKursow;
	}
	
		
	//przeciążenie metody String / int
	public void dodajLicencje(String nazwaLicencji) throws Exception
	{
		if(nazwaLicencji == null)
	{
		throw new Exception("Licencja musi miec nazwe.");
	}
		typLicencji.add(nazwaLicencji);
	}
		
	//przeciążenie metody String / int 
		
	public void dodajLicencje(int numerLicencji) throws Exception
	{
		typLicencji.add(numerLicencji + "");
	}
		
	public void dodajMaszyne(String nazwaMaszyny) throws Exception
	{
		if(nazwaMaszyny == null)
	{
		throw new Exception("Maszyna musi miec nazwe.");
	}
		znajomoscMaszyn.add(nazwaMaszyny);
	}
		
	public String toString()
	{
		//DO opisu Pilota dodajem poprzez użycie super elementów z klasy OSOBA
		String join = super.toString();
		join += "\nLicencje: ";
		
		if(typLicencji.size() > 0)
		{
			for(String nazwaLicencji : typLicencji)
			{
				join += nazwaLicencji + ", ";
			}
		}
		else
		{
			join += "brak licencji";
		}
			return join;
		}
	}
