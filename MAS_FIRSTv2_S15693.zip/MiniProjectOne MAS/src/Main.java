import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Main {

	public static void main(String[] args) throws Exception {
		
		//wczytuje to co było ostatnio zapisane
		if(new File("daneFirmowe").isFile())
		{
			try
			{
				//miejsce docelowe pliku w workspace
				FileInputStream fileInput = new FileInputStream("daneFirmowe");
				ObjectInputStream streamInput = new ObjectInputStream(fileInput);
				//odczyt z dysku do pliku "daneFirmowe"
				ObjectPlus.odczytajEkstensje(streamInput);
				streamInput.close();
				fileInput.close();
			}
			catch(IOException i){
				i.printStackTrace();
				return;
			}
			catch(ClassNotFoundException c){
				System.out.println("Nie znaleziono klasy.");
				c.printStackTrace();
				return;
			}
		}
		
		//utworzenie schematu daty i daty urodzenia
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
		Date date = dateFormat.parse("2000/08/03");
		
		//utworzenie Pilota
		Pilot lotnik = new Pilot("Tomasz","Sokół",date,"Skowronki 7/12", "+42 123 234 1122","Męska", 2);
		//przeciążenie metody string
		lotnik.dodajLicencje("Odludek-Kosmiczny");
		//przeciążenie metody int
		lotnik.dodajLicencje(129321);
		// pokazuje wszystkich Pilotów którzy istnieją
		ObjectPlus.pokazEkstensje(Pilot.class);
		
		
		//zapis ekstenscji do pliku
		//TRWAła Ekstensja
		
		try
		{
			//miejsce docelowe pliku w workspace
			//zapis z dysku do pliku "daneFirmowe"
			FileOutputStream fileOutput = new FileOutputStream("daneFirmy");
			ObjectOutputStream StreamOutput = new ObjectOutputStream(fileOutput);
			ObjectPlus.zapiszEkstensje(StreamOutput);
			StreamOutput.close();
			fileOutput.close();
		}
		catch(IOException i)
		{
			i.printStackTrace();
		}
		
	}

}
